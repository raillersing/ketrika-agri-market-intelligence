"""Read-only admission refusal against every real historical quarantine witness."""
import json
from collections import Counter
from pathlib import Path
from sqlalchemy import text
from ketrika.core.db import get_session
from ketrika.core.models import db
from ketrika.core.quarantine import require_eligible_observation, require_eligible_source

models = {model.__table__.fullname: model for model in (
    db.PriceObservation, db.StockObservation, db.TradeFlow, db.ProductionObservation,
    db.CpiObservation, db.WeatherObservation, db.MacroObservation)}
counts = Counter()
with get_session() as session:
    assert session.bind.url.database == 'ketrika_restore_au08_20261028'
    session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY'))
    assert session.scalar(text('SELECT current_user')) == 'ketrika'
    assert session.scalar(text('SHOW transaction_read_only')) == 'on'
    entries = session.execute(text('SELECT table_name,observation_id,source_record_id,reason_code FROM obs.quarantine_ledger WHERE revoked_at IS NULL')).mappings().all()
    assert len(entries) == 1313
    for entry in entries:
        expected = 'observation_quarantined_identity_reserved'
        try:
            if entry['table_name'] == 'meta.source_record':
                expected = 'observation_source_quarantined'
                assert entry['reason_code'] == 'MISSING_BRONZE_OBJECT'
                require_eligible_source(session, entry['source_record_id'])
            else:
                assert entry['reason_code'] == 'HISTORICAL_SELF_LINK'
                require_eligible_observation(session, models[entry['table_name']], entry['observation_id'])
        except ValueError as exc:
            assert str(exc) == expected
            counts[entry['table_name']] += 1
        else:
            raise AssertionError('Historical quarantine was admitted')
    assert sum(counts.values()) == 1313
    assert session.scalar(text('SELECT count(*) FROM obs.quarantine_ledger WHERE revoked_at IS NULL')) == 1313
with Path('/tmp/au08-real-admission-refusal.json').open('x') as stream:
    json.dump({'passed':True,'role':'ketrika','historic_application_role_qualified':False,'read_only':True,'refusals':dict(counts),
               'total':1313,'source_qualified':False,'r08_qualified':False},stream,sort_keys=True,indent=2)
